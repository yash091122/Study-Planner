"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"
import { v4 as uuidv4 } from "uuid"
import { addDays, parseISO, isAfter, isBefore, addHours } from "date-fns"

// Define types
export type Priority = "low" | "medium" | "high"
export type ClassEvent = {
  id: string
  title: string
  day: string
  startTime: string
  endTime: string
  location: string
  color: string
}

export type Task = {
  id: string
  title: string
  completed: boolean
}

export type Assignment = {
  id: string
  title: string
  dueDate: string
  course: string
  priority: Priority
  progress: number
  tasks: Task[]
  description?: string
}

export type NotificationPreference = {
  email: boolean
  browser: boolean
  mobile: boolean
  beforeClass: number // minutes
  beforeDeadline: number // hours
}

export type AppearancePreference = {
  theme: "light" | "dark" | "system"
  colorScheme: "blue" | "green" | "purple" | "orange"
}

export type AccountInfo = {
  name: string
  email: string
}

export type Settings = {
  notifications: NotificationPreference
  appearance: AppearancePreference
  account: AccountInfo
}

type PlannerContextType = {
  classes: ClassEvent[]
  assignments: Assignment[]
  settings: Settings
  addClass: (classEvent: Omit<ClassEvent, "id">) => void
  updateClass: (classEvent: ClassEvent) => void
  deleteClass: (id: string) => void
  addAssignment: (assignment: Omit<Assignment, "id" | "progress">) => void
  updateAssignment: (assignment: Assignment) => void
  deleteAssignment: (id: string) => void
  toggleTaskCompletion: (assignmentId: string, taskId: string) => void
  addTask: (assignmentId: string, taskTitle: string) => void
  deleteTask: (assignmentId: string, taskId: string) => void
  updateSettings: (newSettings: Settings) => void
  scheduleNotification: (title: string, body: string, delay: number) => void
}

const defaultSettings: Settings = {
  notifications: {
    email: true,
    browser: true,
    mobile: false,
    beforeClass: 15, // minutes
    beforeDeadline: 24, // hours
  },
  appearance: {
    theme: "system",
    colorScheme: "blue",
  },
  account: {
    name: "Student Name",
    email: "student@example.com",
  },
}

// Create context
const PlannerContext = createContext<PlannerContextType | undefined>(undefined)

// Provider component
export const PlannerProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Initialize state with localStorage data if available
  const [classes, setClasses] = useState<ClassEvent[]>(() => {
    if (typeof window !== "undefined") {
      const savedClasses = localStorage.getItem("classes")
      return savedClasses ? JSON.parse(savedClasses) : []
    }
    return []
  })

  const [assignments, setAssignments] = useState<Assignment[]>(() => {
    if (typeof window !== "undefined") {
      const savedAssignments = localStorage.getItem("assignments")
      return savedAssignments ? JSON.parse(savedAssignments) : []
    }
    return []
  })

  const [settings, setSettings] = useState<Settings>(() => {
    if (typeof window !== "undefined") {
      const savedSettings = localStorage.getItem("settings")
      return savedSettings ? JSON.parse(savedSettings) : defaultSettings
    }
    return defaultSettings
  })

  // Save to localStorage whenever state changes
  useEffect(() => {
    if (typeof window !== "undefined") {
      localStorage.setItem("classes", JSON.stringify(classes))
      localStorage.setItem("assignments", JSON.stringify(assignments))
      localStorage.setItem("settings", JSON.stringify(settings))
    }
  }, [classes, assignments, settings])

  // Check for notifications that need to be scheduled
  useEffect(() => {
    if (typeof window !== "undefined" && settings.notifications.browser) {
      // Request notification permission
      if (Notification.permission !== "granted" && Notification.permission !== "denied") {
        Notification.requestPermission()
      }

      // Schedule notifications for upcoming assignments
      assignments.forEach((assignment) => {
        const dueDate = parseISO(assignment.dueDate)
        const now = new Date()
        const notifyTime = addHours(dueDate, -settings.notifications.beforeDeadline)

        if (isAfter(notifyTime, now) && isBefore(notifyTime, addDays(now, 1))) {
          const delay = notifyTime.getTime() - now.getTime()
          scheduleNotification(
            `Assignment Due Soon: ${assignment.title}`,
            `Your ${assignment.course} assignment is due in ${settings.notifications.beforeDeadline} hours.`,
            delay,
          )
        }
      })

      // Schedule notifications for upcoming classes (would need to convert day strings to actual dates)
      // This is simplified for the demo
    }
  }, [assignments, settings.notifications])

  // Add a new class
  const addClass = (classEvent: Omit<ClassEvent, "id">) => {
    const newClass = {
      ...classEvent,
      id: uuidv4(),
    }
    setClasses((prevClasses) => [...prevClasses, newClass])
  }

  // Update an existing class
  const updateClass = (classEvent: ClassEvent) => {
    setClasses((prevClasses) => prevClasses.map((c) => (c.id === classEvent.id ? classEvent : c)))
  }

  // Delete a class
  const deleteClass = (id: string) => {
    setClasses((prevClasses) => prevClasses.filter((c) => c.id !== id))
  }

  // Add a new assignment
  const addAssignment = (assignment: Omit<Assignment, "id" | "progress">) => {
    const newAssignment = {
      ...assignment,
      id: uuidv4(),
      progress: 0,
    }
    setAssignments((prevAssignments) => [...prevAssignments, newAssignment])
  }

  // Update an existing assignment
  const updateAssignment = (assignment: Assignment) => {
    setAssignments((prevAssignments) => prevAssignments.map((a) => (a.id === assignment.id ? assignment : a)))
  }

  // Delete an assignment
  const deleteAssignment = (id: string) => {
    setAssignments((prevAssignments) => prevAssignments.filter((a) => a.id !== id))
  }

  // Toggle task completion
  const toggleTaskCompletion = (assignmentId: string, taskId: string) => {
    setAssignments((prevAssignments) =>
      prevAssignments.map((assignment) => {
        if (assignment.id === assignmentId) {
          const updatedTasks = assignment.tasks.map((task) => {
            if (task.id === taskId) {
              return { ...task, completed: !task.completed }
            }
            return task
          })

          // Calculate new progress
          const completedTasks = updatedTasks.filter((task) => task.completed).length
          const totalTasks = updatedTasks.length
          const progress = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0

          return { ...assignment, tasks: updatedTasks, progress }
        }
        return assignment
      }),
    )
  }

  // Add a new task to an assignment
  const addTask = (assignmentId: string, taskTitle: string) => {
    setAssignments((prevAssignments) =>
      prevAssignments.map((assignment) => {
        if (assignment.id === assignmentId) {
          const newTask = {
            id: uuidv4(),
            title: taskTitle,
            completed: false,
          }
          const updatedTasks = [...assignment.tasks, newTask]

          // Recalculate progress
          const completedTasks = updatedTasks.filter((task) => task.completed).length
          const totalTasks = updatedTasks.length
          const progress = Math.round((completedTasks / totalTasks) * 100)

          return { ...assignment, tasks: updatedTasks, progress }
        }
        return assignment
      }),
    )
  }

  // Delete a task from an assignment
  const deleteTask = (assignmentId: string, taskId: string) => {
    setAssignments((prevAssignments) =>
      prevAssignments.map((assignment) => {
        if (assignment.id === assignmentId) {
          const updatedTasks = assignment.tasks.filter((task) => task.id !== taskId)

          // Recalculate progress
          const completedTasks = updatedTasks.filter((task) => task.completed).length
          const totalTasks = updatedTasks.length
          const progress = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0

          return { ...assignment, tasks: updatedTasks, progress }
        }
        return assignment
      }),
    )
  }

  // Update settings
  const updateSettings = (newSettings: Settings) => {
    setSettings(newSettings)
  }

  // Schedule a notification
  const scheduleNotification = (title: string, body: string, delay: number) => {
    if (typeof window !== "undefined" && Notification.permission === "granted") {
      setTimeout(() => {
        new Notification(title, { body })
      }, delay)
    }
  }

  return (
    <PlannerContext.Provider
      value={{
        classes,
        assignments,
        settings,
        addClass,
        updateClass,
        deleteClass,
        addAssignment,
        updateAssignment,
        deleteAssignment,
        toggleTaskCompletion,
        addTask,
        deleteTask,
        updateSettings,
        scheduleNotification,
      }}
    >
      {children}
    </PlannerContext.Provider>
  )
}

// Custom hook to use the planner context
export const usePlanner = () => {
  const context = useContext(PlannerContext)
  if (context === undefined) {
    throw new Error("usePlanner must be used within a PlannerProvider")
  }
  return context
}

