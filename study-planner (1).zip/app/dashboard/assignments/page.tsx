"use client"

import { useState } from "react"
import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { DashboardShell } from "@/components/dashboard/dashboard-shell"
import { AssignmentList } from "@/components/dashboard/assignment-list"
import { Button } from "@/components/ui/button"
import { PlusCircle } from "lucide-react"
import { AddAssignmentDialog } from "@/components/dashboard/add-assignment-dialog"
import { motion } from "framer-motion"

export default function AssignmentsPage() {
  const [isAddAssignmentOpen, setIsAddAssignmentOpen] = useState(false)

  return (
    <DashboardShell>
      <DashboardHeader heading="Assignments" text="Manage your assignments, track progress, and never miss a deadline.">
        <Button onClick={() => setIsAddAssignmentOpen(true)}>
          <PlusCircle className="mr-2 h-4 w-4" />
          Add Assignment
        </Button>
      </DashboardHeader>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
        <AssignmentList />
      </motion.div>

      <AddAssignmentDialog open={isAddAssignmentOpen} onOpenChange={setIsAddAssignmentOpen} />
    </DashboardShell>
  )
}

