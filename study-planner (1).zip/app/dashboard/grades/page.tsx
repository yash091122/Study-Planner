"use client"
import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { DashboardShell } from "@/components/dashboard/dashboard-shell"
import { GradeCalculator } from "@/components/dashboard/grade-calculator"
import { motion } from "framer-motion"

export default function GradesPage() {
  return (
    <DashboardShell>
      <DashboardHeader heading="Grade Calculator" text="Calculate your current grades and predict final outcomes." />

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
        <GradeCalculator />
      </motion.div>
    </DashboardShell>
  )
}

