"use client"

import { useState } from "react"
import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { DashboardShell } from "@/components/dashboard/dashboard-shell"
import { UpcomingAssignments } from "@/components/dashboard/upcoming-assignments"
import { StudyTimer } from "@/components/dashboard/study-timer"
import { DashboardTabs } from "@/components/dashboard/dashboard-tabs"
import { Button } from "@/components/ui/button"
import { PlusCircle } from "lucide-react"
import { AddClassDialog } from "@/components/dashboard/add-class-dialog"
import { AddAssignmentDialog } from "@/components/dashboard/add-assignment-dialog"
import { motion } from "framer-motion"

export default function DashboardPage() {
  const [isAddClassOpen, setIsAddClassOpen] = useState(false)
  const [isAddAssignmentOpen, setIsAddAssignmentOpen] = useState(false)

  return (
    <DashboardShell>
      <DashboardHeader heading="Dashboard" text="Manage your schedule, assignments, and study sessions.">
        <div className="flex gap-2">
          <Button onClick={() => setIsAddClassOpen(true)}>
            <PlusCircle className="mr-2 h-4 w-4" />
            Add Class
          </Button>
          <Button variant="outline" onClick={() => setIsAddAssignmentOpen(true)}>
            <PlusCircle className="mr-2 h-4 w-4" />
            Add Assignment
          </Button>
        </div>
      </DashboardHeader>

      <motion.div
        className="grid gap-4 md:grid-cols-2 lg:grid-cols-7"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="col-span-4">
          <DashboardTabs />
        </div>
        <div className="col-span-3 space-y-4">
          <UpcomingAssignments />
          <StudyTimer />
        </div>
      </motion.div>

      <AddClassDialog open={isAddClassOpen} onOpenChange={setIsAddClassOpen} />
      <AddAssignmentDialog open={isAddAssignmentOpen} onOpenChange={setIsAddAssignmentOpen} />
    </DashboardShell>
  )
}

