"use client"

import { useState } from "react"
import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { DashboardShell } from "@/components/dashboard/dashboard-shell"
import { WeeklyTimetable } from "@/components/dashboard/weekly-timetable"
import { Button } from "@/components/ui/button"
import { PlusCircle } from "lucide-react"
import { AddClassDialog } from "@/components/dashboard/add-class-dialog"
import { motion } from "framer-motion"

export default function SchedulePage() {
  const [isAddClassOpen, setIsAddClassOpen] = useState(false)

  return (
    <DashboardShell>
      <DashboardHeader heading="Schedule" text="Manage your weekly class schedule and study sessions.">
        <Button onClick={() => setIsAddClassOpen(true)}>
          <PlusCircle className="mr-2 h-4 w-4" />
          Add Class
        </Button>
      </DashboardHeader>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
        <WeeklyTimetable />
      </motion.div>

      <AddClassDialog open={isAddClassOpen} onOpenChange={setIsAddClassOpen} />
    </DashboardShell>
  )
}

