"use client"

import type React from "react"

import { useState } from "react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { usePlanner } from "@/app/context/planner-context"
import { useToast } from "@/components/ui/use-toast"

interface AddAssignmentDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function AddAssignmentDialog({ open, onOpenChange }: AddAssignmentDialogProps) {
  const { addAssignment } = usePlanner()
  const { toast } = useToast()

  const [formData, setFormData] = useState({
    title: "",
    dueDate: "",
    course: "",
    priority: "medium",
    description: "",
    tasks: [],
  })

  const [taskTitle, setTaskTitle] = useState("")

  const handleChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const handleAddTask = () => {
    if (taskTitle.trim()) {
      setFormData((prev) => ({
        ...prev,
        tasks: [...prev.tasks, { id: `temp-${Date.now()}`, title: taskTitle.trim(), completed: false }],
      }))
      setTaskTitle("")
    }
  }

  const handleRemoveTask = (index: number) => {
    setFormData((prev) => ({
      ...prev,
      tasks: prev.tasks.filter((_, i) => i !== index),
    }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    // Validate form
    if (!formData.title || !formData.dueDate || !formData.course) {
      toast({
        title: "Missing information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      })
      return
    }

    // Add assignment
    addAssignment(formData)

    // Reset form and close dialog
    setFormData({
      title: "",
      dueDate: "",
      course: "",
      priority: "medium",
      description: "",
      tasks: [],
    })

    onOpenChange(false)

    toast({
      title: "Assignment added",
      description: "Your assignment has been added to your list.",
    })
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Add New Assignment</DialogTitle>
          <DialogDescription>Add a new assignment to track your progress.</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="title">Assignment Title</Label>
              <Input
                id="title"
                value={formData.title}
                onChange={(e) => handleChange("title", e.target.value)}
                placeholder="e.g., Calculus Problem Set"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="course">Course</Label>
                <Input
                  id="course"
                  value={formData.course}
                  onChange={(e) => handleChange("course", e.target.value)}
                  placeholder="e.g., Calculus I"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="priority">Priority</Label>
                <Select value={formData.priority} onValueChange={(value) => handleChange("priority", value)}>
                  <SelectTrigger id="priority">
                    <SelectValue placeholder="Select priority" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="dueDate">Due Date</Label>
              <Input
                id="dueDate"
                type="date"
                value={formData.dueDate}
                onChange={(e) => handleChange("dueDate", e.target.value)}
                min={new Date().toISOString().split("T")[0]}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="description">Description (Optional)</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => handleChange("description", e.target.value)}
                placeholder="Add any additional details about the assignment"
                rows={3}
              />
            </div>
            <div className="grid gap-2">
              <Label>Tasks</Label>
              <div className="flex gap-2">
                <Input
                  value={taskTitle}
                  onChange={(e) => setTaskTitle(e.target.value)}
                  placeholder="Enter task title"
                  className="flex-1"
                />
                <Button type="button" onClick={handleAddTask}>
                  Add
                </Button>
              </div>
              {formData.tasks.length > 0 && (
                <div className="mt-2 space-y-2">
                  {formData.tasks.map((task, index) => (
                    <div key={task.id} className="flex items-center justify-between bg-muted p-2 rounded-md">
                      <span>{task.title}</span>
                      <Button type="button" variant="ghost" size="sm" onClick={() => handleRemoveTask(index)}>
                        Remove
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
          <DialogFooter>
            <Button type="submit">Add Assignment</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}

