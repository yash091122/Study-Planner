"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { cn } from "@/lib/utils"
import { usePlanner } from "@/app/context/planner-context"
import { Edit, Trash2, Plus } from "lucide-react"
import { EditAssignmentDialog } from "@/components/dashboard/edit-assignment-dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { useToast } from "@/components/ui/use-toast"
import { motion, AnimatePresence } from "framer-motion"

export function AssignmentList() {
  const { assignments, toggleTaskCompletion, deleteAssignment, addTask, deleteTask } = usePlanner()
  const [activeTab, setActiveTab] = useState("all")
  const [editingAssignment, setEditingAssignment] = useState(null)
  const [deletingAssignmentId, setDeletingAssignmentId] = useState(null)
  const [newTaskTitle, setNewTaskTitle] = useState("")
  const [addingTaskForId, setAddingTaskForId] = useState(null)
  const { toast } = useToast()

  // Sort assignments by due date
  const sortedAssignments = [...assignments].sort(
    (a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime(),
  )

  // Filter assignments based on active tab
  const filteredAssignments = sortedAssignments.filter((assignment) => {
    if (activeTab === "all") return true
    if (activeTab === "upcoming") {
      const dueDate = new Date(assignment.dueDate)
      const today = new Date()
      const diffTime = dueDate.getTime() - today.getTime()
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
      return diffDays <= 7 && diffDays >= 0
    }
    if (activeTab === "completed") return assignment.progress === 100
    return true
  })

  // Calculate days remaining
  const getDaysRemaining = (dueDate) => {
    const today = new Date()
    const due = new Date(dueDate)
    const diffTime = due.getTime() - today.getTime()
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
    return diffDays
  }

  // Get priority badge color
  const getPriorityColor = (priority) => {
    switch (priority) {
      case "high":
        return "bg-red-500 hover:bg-red-600"
      case "medium":
        return "bg-yellow-500 hover:bg-yellow-600"
      case "low":
        return "bg-green-500 hover:bg-green-600"
      default:
        return "bg-blue-500 hover:bg-blue-600"
    }
  }

  const handleEdit = (assignment) => {
    setEditingAssignment(assignment)
  }

  const handleDelete = (id) => {
    setDeletingAssignmentId(id)
  }

  const confirmDelete = () => {
    if (deletingAssignmentId) {
      deleteAssignment(deletingAssignmentId)
      setDeletingAssignmentId(null)
      toast({
        title: "Assignment deleted",
        description: "The assignment has been removed.",
      })
    }
  }

  const handleAddTask = (assignmentId) => {
    if (newTaskTitle.trim()) {
      addTask(assignmentId, newTaskTitle.trim())
      setNewTaskTitle("")
      setAddingTaskForId(null)
      toast({
        title: "Task added",
        description: "New task has been added to the assignment.",
      })
    }
  }

  const handleDeleteTask = (assignmentId, taskId) => {
    deleteTask(assignmentId, taskId)
    toast({
      title: "Task deleted",
      description: "The task has been removed from the assignment.",
    })
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.3,
      },
    },
  }

  return (
    <>
      <Card className="col-span-4">
        <CardHeader>
          <CardTitle>Assignments</CardTitle>
          <CardDescription>Track your assignments and their progress</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="all" className="w-full" onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
              <TabsTrigger value="completed">Completed</TabsTrigger>
            </TabsList>
            <TabsContent value={activeTab}>
              <motion.div className="space-y-6 mt-4" variants={containerVariants} initial="hidden" animate="visible">
                <AnimatePresence>
                  {filteredAssignments.length > 0 ? (
                    filteredAssignments.map((assignment) => {
                      const daysRemaining = getDaysRemaining(assignment.dueDate)
                      return (
                        <motion.div
                          key={assignment.id}
                          className="border rounded-lg p-4 space-y-4"
                          variants={itemVariants}
                          layout
                        >
                          <div className="flex items-center justify-between">
                            <div>
                              <div className="text-xl font-medium">{assignment.title}</div>
                              <div className="text-sm text-muted-foreground">{assignment.course}</div>
                            </div>
                            <div className="flex gap-2">
                              <Badge className={cn(getPriorityColor(assignment.priority))}>{assignment.priority}</Badge>
                              <Button size="icon" variant="ghost" onClick={() => handleEdit(assignment)}>
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button size="icon" variant="ghost" onClick={() => handleDelete(assignment.id)}>
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <Progress value={assignment.progress} className="h-2" />
                            <span className="text-sm text-muted-foreground">{assignment.progress}%</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span>Due: {new Date(assignment.dueDate).toLocaleDateString()}</span>
                            <span
                              className={cn(
                                daysRemaining <= 3
                                  ? "text-red-500"
                                  : daysRemaining <= 7
                                    ? "text-yellow-500"
                                    : "text-green-500",
                              )}
                            >
                              {daysRemaining} days left
                            </span>
                          </div>
                          {assignment.description && (
                            <div className="text-sm text-muted-foreground">{assignment.description}</div>
                          )}
                          <div className="space-y-2">
                            <div className="font-medium flex justify-between items-center">
                              <span>Tasks</span>
                              <Button size="sm" variant="ghost" onClick={() => setAddingTaskForId(assignment.id)}>
                                <Plus className="h-4 w-4 mr-1" /> Add Task
                              </Button>
                            </div>
                            {addingTaskForId === assignment.id && (
                              <motion.div
                                className="flex gap-2 items-center"
                                initial={{ opacity: 0, height: 0 }}
                                animate={{ opacity: 1, height: "auto" }}
                                exit={{ opacity: 0, height: 0 }}
                              >
                                <Input
                                  value={newTaskTitle}
                                  onChange={(e) => setNewTaskTitle(e.target.value)}
                                  placeholder="Enter task title"
                                  className="flex-1"
                                />
                                <Button size="sm" onClick={() => handleAddTask(assignment.id)}>
                                  Add
                                </Button>
                                <Button size="sm" variant="ghost" onClick={() => setAddingTaskForId(null)}>
                                  Cancel
                                </Button>
                              </motion.div>
                            )}
                            <AnimatePresence>
                              {assignment.tasks.map((task) => (
                                <motion.div
                                  key={task.id}
                                  className="flex items-center justify-between"
                                  initial={{ opacity: 0, height: 0 }}
                                  animate={{ opacity: 1, height: "auto" }}
                                  exit={{ opacity: 0, height: 0 }}
                                  transition={{ duration: 0.2 }}
                                >
                                  <div className="flex items-center space-x-2">
                                    <Checkbox
                                      id={task.id}
                                      checked={task.completed}
                                      onCheckedChange={() => toggleTaskCompletion(assignment.id, task.id)}
                                    />
                                    <Label
                                      htmlFor={task.id}
                                      className={cn(task.completed && "line-through text-muted-foreground")}
                                    >
                                      {task.title}
                                    </Label>
                                  </div>
                                  <Button
                                    size="icon"
                                    variant="ghost"
                                    className="h-6 w-6"
                                    onClick={() => handleDeleteTask(assignment.id, task.id)}
                                  >
                                    <Trash2 className="h-3 w-3" />
                                  </Button>
                                </motion.div>
                              ))}
                            </AnimatePresence>
                          </div>
                        </motion.div>
                      )
                    })
                  ) : (
                    <motion.div
                      className="text-center py-8 text-muted-foreground"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                    >
                      No assignments found
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {editingAssignment && (
        <EditAssignmentDialog
          assignment={editingAssignment}
          open={!!editingAssignment}
          onOpenChange={(open) => !open && setEditingAssignment(null)}
        />
      )}

      <AlertDialog open={!!deletingAssignmentId} onOpenChange={(open) => !open && setDeletingAssignmentId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will remove the assignment and all associated tasks. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  )
}

