"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Calendar, ClipboardList, Home, Settings, Calculator } from "lucide-react"
import { motion } from "framer-motion"

export function DashboardNav() {
  const pathname = usePathname()

  const navItems = [
    {
      title: "Dashboard",
      href: "/dashboard",
      icon: Home,
    },
    {
      title: "Schedule",
      href: "/dashboard/schedule",
      icon: Calendar,
    },
    {
      title: "Assignments",
      href: "/dashboard/assignments",
      icon: ClipboardList,
    },
    {
      title: "Grade Calculator",
      href: "/dashboard/grades",
      icon: Calculator,
    },
    {
      title: "Settings",
      href: "/dashboard/settings",
      icon: Settings,
    },
  ]

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const item = {
    hidden: { opacity: 0, x: -20 },
    show: { opacity: 1, x: 0 },
  }

  return (
    <motion.nav className="grid items-start gap-2 mt-8" variants={container} initial="hidden" animate="show">
      {navItems.map((item, index) => (
        <motion.div key={item.href} variants={item}>
          <Link href={item.href}>
            <Button
              variant={pathname === item.href ? "secondary" : "ghost"}
              className={cn("w-full justify-start", pathname === item.href && "bg-muted font-medium")}
            >
              <item.icon className="mr-2 h-4 w-4" />
              {item.title}
            </Button>
          </Link>
        </motion.div>
      ))}
    </motion.nav>
  )
}

