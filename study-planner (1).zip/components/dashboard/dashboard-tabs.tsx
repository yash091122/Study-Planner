"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { WeeklyTimetable } from "@/components/dashboard/weekly-timetable"
import { AssignmentList } from "@/components/dashboard/assignment-list"
import { motion, AnimatePresence } from "framer-motion"

export function DashboardTabs() {
  const [activeTab, setActiveTab] = useState("schedule")

  return (
    <Tabs defaultValue="schedule" className="w-full" onValueChange={setActiveTab}>
      <TabsList className="grid w-full grid-cols-2">
        <TabsTrigger value="schedule">Schedule</TabsTrigger>
        <TabsTrigger value="assignments">Assignments</TabsTrigger>
      </TabsList>
      <AnimatePresence mode="wait">
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.2 }}
        >
          <TabsContent value="schedule">
            <WeeklyTimetable />
          </TabsContent>
          <TabsContent value="assignments">
            <AssignmentList />
          </TabsContent>
        </motion.div>
      </AnimatePresence>
    </Tabs>
  )
}

