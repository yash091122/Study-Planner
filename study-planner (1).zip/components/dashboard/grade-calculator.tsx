"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Trash2, Plus, Download } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import { useToast } from "@/components/ui/use-toast"

type GradeItem = {
  id: string
  name: string
  weight: number
  score: number
  maxScore: number
}

export function GradeCalculator() {
  const [courses, setCourses] = useState([
    {
      id: "course-1",
      name: "Calculus I",
      items: [
        { id: "item-1", name: "Midterm", weight: 30, score: 85, maxScore: 100 },
        { id: "item-2", name: "Final Exam", weight: 40, score: 0, maxScore: 100 },
        { id: "item-3", name: "Homework", weight: 20, score: 90, maxScore: 100 },
        { id: "item-4", name: "Quizzes", weight: 10, score: 88, maxScore: 100 },
      ],
    },
  ])

  const [activeCourse, setActiveCourse] = useState("course-1")
  const [newCourseName, setNewCourseName] = useState("")
  const [isAddingCourse, setIsAddingCourse] = useState(false)
  const { toast } = useToast()

  const getActiveCourse = () => {
    return courses.find((course) => course.id === activeCourse) || courses[0]
  }

  const calculateGrade = (items: GradeItem[]) => {
    if (items.length === 0) return 0

    let totalWeight = 0
    let weightedScore = 0

    items.forEach((item) => {
      const percentage = (item.score / item.maxScore) * 100
      weightedScore += (percentage * item.weight) / 100
      totalWeight += item.weight
    })

    return totalWeight > 0 ? weightedScore / (totalWeight / 100) : 0
  }

  const getLetterGrade = (score: number) => {
    if (score >= 90) return "A"
    if (score >= 80) return "B"
    if (score >= 70) return "C"
    if (score >= 60) return "D"
    return "F"
  }

  const handleAddCourse = () => {
    if (newCourseName.trim()) {
      const newCourse = {
        id: `course-${Date.now()}`,
        name: newCourseName.trim(),
        items: [],
      }
      setCourses([...courses, newCourse])
      setActiveCourse(newCourse.id)
      setNewCourseName("")
      setIsAddingCourse(false)

      toast({
        title: "Course added",
        description: "New course has been added to your grade calculator.",
      })
    }
  }

  const handleDeleteCourse = (courseId: string) => {
    if (courses.length <= 1) {
      toast({
        title: "Cannot delete course",
        description: "You must have at least one course.",
        variant: "destructive",
      })
      return
    }

    const newCourses = courses.filter((course) => course.id !== courseId)
    setCourses(newCourses)

    if (courseId === activeCourse) {
      setActiveCourse(newCourses[0].id)
    }

    toast({
      title: "Course deleted",
      description: "The course has been removed from your grade calculator.",
    })
  }

  const handleAddItem = () => {
    const newItem = {
      id: `item-${Date.now()}`,
      name: "New Item",
      weight: 0,
      score: 0,
      maxScore: 100,
    }

    setCourses(
      courses.map((course) => {
        if (course.id === activeCourse) {
          return {
            ...course,
            items: [...course.items, newItem],
          }
        }
        return course
      }),
    )

    toast({
      title: "Item added",
      description: "New graded item has been added to the course.",
    })
  }

  const handleDeleteItem = (itemId: string) => {
    setCourses(
      courses.map((course) => {
        if (course.id === activeCourse) {
          return {
            ...course,
            items: course.items.filter((item) => item.id !== itemId),
          }
        }
        return course
      }),
    )

    toast({
      title: "Item deleted",
      description: "The graded item has been removed from the course.",
    })
  }

  const handleItemChange = (itemId: string, field: string, value: string | number) => {
    setCourses(
      courses.map((course) => {
        if (course.id === activeCourse) {
          return {
            ...course,
            items: course.items.map((item) => {
              if (item.id === itemId) {
                return {
                  ...item,
                  [field]: typeof value === "string" ? value : Number(value),
                }
              }
              return item
            }),
          }
        }
        return course
      }),
    )
  }

  const exportGrades = () => {
    const course = getActiveCourse()
    const grade = calculateGrade(course.items)
    const letterGrade = getLetterGrade(grade)

    const data = {
      course: course.name,
      grade: grade.toFixed(2),
      letterGrade,
      items: course.items,
    }

    const jsonString = JSON.stringify(data, null, 2)
    const blob = new Blob([jsonString], { type: "application/json" })
    const url = URL.createObjectURL(blob)

    const a = document.createElement("a")
    a.href = url
    a.download = `${course.name.replace(/\s+/g, "-").toLowerCase()}-grades.json`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)

    toast({
      title: "Grades exported",
      description: "Your grades have been exported as a JSON file.",
    })
  }

  const currentCourse = getActiveCourse()
  const currentGrade = calculateGrade(currentCourse.items)
  const letterGrade = getLetterGrade(currentGrade)

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle>Grade Calculator</CardTitle>
            <CardDescription>Calculate your current grades and predict final outcomes</CardDescription>
          </div>
          <Button variant="outline" size="sm" onClick={exportGrades}>
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
          <div className="flex-1">
            <Label htmlFor="course-select">Select Course</Label>
            <Select value={activeCourse} onValueChange={setActiveCourse}>
              <SelectTrigger id="course-select">
                <SelectValue placeholder="Select a course" />
              </SelectTrigger>
              <SelectContent>
                {courses.map((course) => (
                  <SelectItem key={course.id} value={course.id}>
                    {course.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="flex gap-2">
            {isAddingCourse ? (
              <div className="flex gap-2">
                <Input
                  value={newCourseName}
                  onChange={(e) => setNewCourseName(e.target.value)}
                  placeholder="Course name"
                  className="w-40"
                />
                <Button size="sm" onClick={handleAddCourse}>
                  Add
                </Button>
                <Button size="sm" variant="ghost" onClick={() => setIsAddingCourse(false)}>
                  Cancel
                </Button>
              </div>
            ) : (
              <Button size="sm" variant="outline" onClick={() => setIsAddingCourse(true)}>
                <Plus className="mr-2 h-4 w-4" />
                Add Course
              </Button>
            )}

            <Button size="sm" variant="ghost" onClick={() => handleDeleteCourse(activeCourse)}>
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <div className="border rounded-lg p-4">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-medium">{currentCourse.name}</h3>
            <div className="flex items-center gap-4">
              <div className="text-right">
                <div className="text-sm text-muted-foreground">Current Grade</div>
                <div className="text-2xl font-bold">{currentGrade.toFixed(1)}%</div>
              </div>
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                <span className="text-xl font-bold">{letterGrade}</span>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div className="grid grid-cols-12 gap-2 font-medium text-sm">
              <div className="col-span-4">Item</div>
              <div className="col-span-2 text-center">Weight (%)</div>
              <div className="col-span-2 text-center">Score</div>
              <div className="col-span-2 text-center">Max Score</div>
              <div className="col-span-2 text-center">Percentage</div>
            </div>

            <AnimatePresence>
              {currentCourse.items.map((item) => (
                <motion.div
                  key={item.id}
                  className="grid grid-cols-12 gap-2 items-center"
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.2 }}
                >
                  <div className="col-span-4">
                    <Input
                      value={item.name}
                      onChange={(e) => handleItemChange(item.id, "name", e.target.value)}
                      className="h-8"
                    />
                  </div>
                  <div className="col-span-2">
                    <Input
                      type="number"
                      value={item.weight}
                      onChange={(e) => handleItemChange(item.id, "weight", e.target.valueAsNumber)}
                      className="h-8 text-center"
                      min={0}
                      max={100}
                    />
                  </div>
                  <div className="col-span-2">
                    <Input
                      type="number"
                      value={item.score}
                      onChange={(e) => handleItemChange(item.id, "score", e.target.valueAsNumber)}
                      className="h-8 text-center"
                      min={0}
                    />
                  </div>
                  <div className="col-span-2">
                    <Input
                      type="number"
                      value={item.maxScore}
                      onChange={(e) => handleItemChange(item.id, "maxScore", e.target.valueAsNumber)}
                      className="h-8 text-center"
                      min={1}
                    />
                  </div>
                  <div className="col-span-1 text-center">{((item.score / item.maxScore) * 100).toFixed(1)}%</div>
                  <div className="col-span-1 flex justify-end">
                    <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => handleDeleteItem(item.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>

            <Button variant="outline" size="sm" onClick={handleAddItem} className="w-full mt-2">
              <Plus className="mr-2 h-4 w-4" />
              Add Item
            </Button>
          </div>
        </div>
      </CardContent>
      <CardFooter className="flex justify-between">
        <div>
          <p className="text-sm text-muted-foreground">
            Grade Scale: A (90-100%), B (80-89%), C (70-79%), D (60-69%), F (0-59%)
          </p>
        </div>
        <div className="text-right">
          <div className="text-sm text-muted-foreground">Final Grade</div>
          <div className="text-xl font-bold">
            {currentGrade.toFixed(1)}% ({letterGrade})
          </div>
        </div>
      </CardFooter>
    </Card>
  )
}

