"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Play, Pause, RotateCcw, Volume2, VolumeX } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import { useToast } from "@/components/ui/use-toast"

export function StudyTimer() {
  const [isActive, setIsActive] = useState(false)
  const [isPaused, setIsPaused] = useState(true)
  const [time, setTime] = useState(25 * 60) // 25 minutes in seconds
  const [sessionLength, setSessionLength] = useState(25)
  const [breakLength, setBreakLength] = useState(5)
  const [isSession, setIsSession] = useState(true)
  const [isMuted, setIsMuted] = useState(false)
  const { toast } = useToast()

  // Circular progress calculation
  const totalSeconds = isSession ? sessionLength * 60 : breakLength * 60
  const progress = (totalSeconds - time) / totalSeconds
  const circumference = 2 * Math.PI * 45 // 45 is the radius of the circle
  const strokeDashoffset = circumference * (1 - progress)

  useEffect(() => {
    let interval = null

    if (isActive && !isPaused) {
      interval = setInterval(() => {
        setTime((time) => {
          if (time <= 1) {
            // Timer completed
            clearInterval(interval)

            // Play sound if not muted
            if (!isMuted) {
              const audio = new Audio("/notification.mp3")
              audio.play().catch((e) => console.log("Audio play failed:", e))
            }

            // Show notification
            if (Notification.permission === "granted") {
              new Notification(isSession ? "Break Time!" : "Focus Session!", {
                body: isSession
                  ? `Great job! Take a ${breakLength} minute break.`
                  : `Time to focus for ${sessionLength} minutes.`,
              })
            }

            // Show toast
            toast({
              title: isSession ? "Break Time!" : "Focus Session!",
              description: isSession
                ? `Great job! Take a ${breakLength} minute break.`
                : `Time to focus for ${sessionLength} minutes.`,
            })

            // Switch between session and break
            setIsSession(!isSession)
            return isSession ? breakLength * 60 : sessionLength * 60
          }
          return time - 1
        })
      }, 1000)
    } else {
      clearInterval(interval)
    }

    return () => clearInterval(interval)
  }, [isActive, isPaused, isSession, sessionLength, breakLength, isMuted, toast])

  // Request notification permission
  useEffect(() => {
    if (Notification.permission !== "granted" && Notification.permission !== "denied") {
      Notification.requestPermission()
    }
  }, [])

  const handleStart = () => {
    setIsActive(true)
    setIsPaused(false)
  }

  const handlePause = () => {
    setIsPaused(true)
  }

  const handleResume = () => {
    setIsPaused(false)
  }

  const handleReset = () => {
    setIsActive(false)
    setIsPaused(true)
    setTime(sessionLength * 60)
    setIsSession(true)
  }

  const formatTime = () => {
    const minutes = Math.floor(time / 60)
    const seconds = time % 60
    return `${minutes.toString().padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`
  }

  const handleSessionChange = (value) => {
    if (!isActive) {
      setSessionLength(value[0])
      if (isSession) setTime(value[0] * 60)
    }
  }

  const handleBreakChange = (value) => {
    if (!isActive) {
      setBreakLength(value[0])
      if (!isSession) setTime(value[0] * 60)
    }
  }

  const toggleMute = () => {
    setIsMuted(!isMuted)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Study Timer</CardTitle>
        <CardDescription>Use the Pomodoro technique to stay focused</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col items-center space-y-6">
          <div className="relative">
            <svg width="120" height="120" viewBox="0 0 100 100">
              <circle
                cx="50"
                cy="50"
                r="45"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                className="text-muted-foreground/20"
              />
              <motion.circle
                cx="50"
                cy="50"
                r="45"
                fill="none"
                stroke="currentColor"
                strokeWidth="5"
                strokeLinecap="round"
                strokeDasharray={circumference}
                strokeDashoffset={strokeDashoffset}
                className={isSession ? "text-primary" : "text-green-500"}
                initial={{ strokeDashoffset: circumference }}
                animate={{ strokeDashoffset }}
                transition={{ duration: 0.5 }}
              />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center">
              <motion.div
                className="text-4xl font-bold"
                key={time}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.2 }}
              >
                {formatTime()}
              </motion.div>
            </div>
          </div>

          <motion.div
            className="text-lg font-medium"
            animate={{
              color: isSession ? "var(--primary)" : "var(--green-500)",
            }}
          >
            {isSession ? "Focus Session" : "Break Time"}
          </motion.div>

          <div className="flex space-x-2">
            <AnimatePresence mode="wait">
              {isPaused ? (
                <motion.div
                  key="start"
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.8 }}
                  transition={{ duration: 0.2 }}
                >
                  <Button onClick={isActive ? handleResume : handleStart}>
                    <Play className="mr-2 h-4 w-4" />
                    {isActive ? "Resume" : "Start"}
                  </Button>
                </motion.div>
              ) : (
                <motion.div
                  key="pause"
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.8 }}
                  transition={{ duration: 0.2 }}
                >
                  <Button onClick={handlePause}>
                    <Pause className="mr-2 h-4 w-4" />
                    Pause
                  </Button>
                </motion.div>
              )}
            </AnimatePresence>
            <Button variant="outline" onClick={handleReset}>
              <RotateCcw className="mr-2 h-4 w-4" />
              Reset
            </Button>
            <Button variant="ghost" size="icon" onClick={toggleMute}>
              {isMuted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
            </Button>
          </div>

          <div className="w-full space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm font-medium">Session Length: {sessionLength} min</span>
              </div>
              <Slider
                defaultValue={[sessionLength]}
                max={60}
                min={5}
                step={5}
                onValueChange={handleSessionChange}
                disabled={isActive}
              />
            </div>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm font-medium">Break Length: {breakLength} min</span>
              </div>
              <Slider
                defaultValue={[breakLength]}
                max={30}
                min={1}
                step={1}
                onValueChange={handleBreakChange}
                disabled={isActive}
              />
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

