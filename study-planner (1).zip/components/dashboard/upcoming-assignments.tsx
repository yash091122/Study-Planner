"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { cn } from "@/lib/utils"
import { usePlanner } from "@/app/context/planner-context"
import { Button } from "@/components/ui/button"
import { useRouter } from "next/navigation"
import { motion, AnimatePresence } from "framer-motion"

export function UpcomingAssignments() {
  const { assignments } = usePlanner()
  const router = useRouter()

  // Sort assignments by due date
  const sortedAssignments = [...assignments]
    .sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime())
    .slice(0, 3) // Only show the 3 most upcoming assignments

  // Calculate days remaining
  const getDaysRemaining = (dueDate: string) => {
    const today = new Date()
    const due = new Date(dueDate)
    const diffTime = due.getTime() - today.getTime()
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
    return diffDays
  }

  // Get priority badge color
  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "bg-red-500 hover:bg-red-600"
      case "medium":
        return "bg-yellow-500 hover:bg-yellow-600"
      case "low":
        return "bg-green-500 hover:bg-green-600"
      default:
        return "bg-blue-500 hover:bg-blue-600"
    }
  }

  const handleViewAll = () => {
    router.push("/dashboard/assignments")
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>Upcoming Assignments</CardTitle>
          <CardDescription>Track your progress and upcoming deadlines</CardDescription>
        </div>
        <Button variant="outline" size="sm" onClick={handleViewAll}>
          View All
        </Button>
      </CardHeader>
      <CardContent>
        <AnimatePresence>
          {sortedAssignments.length > 0 ? (
            <div className="space-y-4">
              {sortedAssignments.map((assignment, index) => {
                const daysRemaining = getDaysRemaining(assignment.dueDate)
                return (
                  <motion.div
                    key={assignment.id}
                    className="flex flex-col space-y-2"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.1 }}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium">{assignment.title}</div>
                        <div className="text-sm text-muted-foreground">{assignment.course}</div>
                      </div>
                      <Badge className={cn(getPriorityColor(assignment.priority))}>{assignment.priority}</Badge>
                    </div>
                    <div className="flex items-center gap-2">
                      <Progress value={assignment.progress} className="h-2" />
                      <span className="text-sm text-muted-foreground">{assignment.progress}%</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Due: {new Date(assignment.dueDate).toLocaleDateString()}</span>
                      <span
                        className={cn(
                          daysRemaining <= 3
                            ? "text-red-500"
                            : daysRemaining <= 7
                              ? "text-yellow-500"
                              : "text-green-500",
                        )}
                      >
                        {daysRemaining} days left
                      </span>
                    </div>
                  </motion.div>
                )
              })}
            </div>
          ) : (
            <motion.div
              className="text-center py-8 text-muted-foreground"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5 }}
            >
              No upcoming assignments
            </motion.div>
          )}
        </AnimatePresence>
      </CardContent>
    </Card>
  )
}

