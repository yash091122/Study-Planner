"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { cn } from "@/lib/utils"
import { usePlanner } from "@/app/context/planner-context"
import type { ClassEvent } from "@/app/context/planner-context"
import { Button } from "@/components/ui/button"
import { Edit, Trash2 } from "lucide-react"
import { EditClassDialog } from "@/components/dashboard/edit-class-dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { motion, AnimatePresence } from "framer-motion"
import { useToast } from "@/components/ui/use-toast"

const daysOfWeek = ["monday", "tuesday", "wednesday", "thursday", "friday"]
const timeSlots = Array.from({ length: 12 }, (_, i) => `${i + 8}:00`)

export function WeeklyTimetable() {
  const { classes, deleteClass } = usePlanner()
  const [draggedClass, setDraggedClass] = useState<ClassEvent | null>(null)
  const [editingClass, setEditingClass] = useState<ClassEvent | null>(null)
  const [deletingClassId, setDeletingClassId] = useState<string | null>(null)
  const { toast } = useToast()

  // Function to get classes for a specific day and time
  const getClassForTimeSlot = (day: string, time: string) => {
    return classes.find(
      (cls) =>
        cls.day === day &&
        Number.parseInt(cls.startTime.split(":")[0]) <= Number.parseInt(time.split(":")[0]) &&
        Number.parseInt(cls.endTime.split(":")[0]) > Number.parseInt(time.split(":")[0]),
    )
  }

  const handleDragStart = (classEvent: ClassEvent) => {
    setDraggedClass(classEvent)
  }

  const handleDragOver = (e: React.DragEvent, day: string, time: string) => {
    e.preventDefault()
  }

  const handleDrop = (e: React.DragEvent, day: string, time: string) => {
    e.preventDefault()
    // In a real implementation, you would update the class with the new day and time
    // For now, we'll just show a toast notification
    if (draggedClass) {
      toast({
        title: "Class moved",
        description: `${draggedClass.title} moved to ${day} at ${time}`,
      })
      setDraggedClass(null)
    }
  }

  const handleEdit = (classEvent: ClassEvent) => {
    setEditingClass(classEvent)
  }

  const handleDelete = (id: string) => {
    setDeletingClassId(id)
  }

  const confirmDelete = () => {
    if (deletingClassId) {
      deleteClass(deletingClassId)
      setDeletingClassId(null)
      toast({
        title: "Class deleted",
        description: "The class has been removed from your schedule.",
      })
    }
  }

  return (
    <>
      <Card className="col-span-4">
        <CardHeader>
          <CardTitle>Weekly Schedule</CardTitle>
          <CardDescription>Drag and drop classes to rearrange your schedule</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-6 gap-2 overflow-x-auto">
            <div className="sticky left-0 bg-background">
              <div className="h-12"></div>
              {timeSlots.map((time) => (
                <div key={time} className="h-16 border-t pt-2 text-sm text-muted-foreground">
                  {time}
                </div>
              ))}
            </div>
            {daysOfWeek.map((day) => (
              <div key={day} className="space-y-2">
                <div className="h-12 text-center font-medium capitalize">{day}</div>
                {timeSlots.map((time) => {
                  const classItem = getClassForTimeSlot(day, time)
                  return (
                    <div
                      key={`${day}-${time}`}
                      className={cn(
                        "h-16 rounded-md border border-dashed p-2 transition-all",
                        classItem ? classItem.color : "border-muted-foreground/20 hover:border-muted-foreground/40",
                      )}
                      onDragOver={(e) => handleDragOver(e, day, time)}
                      onDrop={(e) => handleDrop(e, day, time)}
                    >
                      <AnimatePresence>
                        {classItem && (
                          <motion.div
                            className="flex h-full flex-col text-white relative group"
                            draggable
                            onDragStart={() => handleDragStart(classItem)}
                            initial={{ opacity: 0, scale: 0.9 }}
                            animate={{ opacity: 1, scale: 1 }}
                            exit={{ opacity: 0, scale: 0.9 }}
                            transition={{ duration: 0.2 }}
                          >
                            <div className="text-xs font-medium">{classItem.title}</div>
                            <div className="text-xs">
                              {classItem.startTime} - {classItem.endTime}
                            </div>
                            <div className="text-xs">{classItem.location}</div>
                            <div className="absolute top-0 right-0 opacity-0 group-hover:opacity-100 transition-opacity flex gap-1">
                              <Button
                                size="icon"
                                variant="ghost"
                                className="h-5 w-5 bg-white/20 hover:bg-white/30"
                                onClick={() => handleEdit(classItem)}
                              >
                                <Edit className="h-3 w-3" />
                              </Button>
                              <Button
                                size="icon"
                                variant="ghost"
                                className="h-5 w-5 bg-white/20 hover:bg-white/30"
                                onClick={() => handleDelete(classItem.id)}
                              >
                                <Trash2 className="h-3 w-3" />
                              </Button>
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  )
                })}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {editingClass && (
        <EditClassDialog
          classEvent={editingClass}
          open={!!editingClass}
          onOpenChange={(open) => !open && setEditingClass(null)}
        />
      )}

      <AlertDialog open={!!deletingClassId} onOpenChange={(open) => !open && setDeletingClassId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will remove the class from your schedule. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  )
}

